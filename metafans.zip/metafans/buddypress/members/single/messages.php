<?php
/**
 * BuddyPress - Users Messages
 *
 * @version 3.0.0
 */

	do_action( 'tophive/buddypress/messenger' );
?>

