<?php
class Tophive_Customizer_Control_Hr extends Tophive_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-tophive-hr">
		<?php
		echo '<hr/>';
		?>
		</script>
		<?php
	}
}
